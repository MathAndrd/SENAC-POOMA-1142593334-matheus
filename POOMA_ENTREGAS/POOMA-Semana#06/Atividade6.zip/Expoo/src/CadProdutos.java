import javax.swing.JDialog;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class CadProdutos {
    private ArrayList<Produto> listaProdutos = new ArrayList<>();

    public CadProdutos() {
        listaProdutos = new ArrayList<>();
    }

    public void adicionarProduto(Produto produto) {
        int novoId = listaProdutos.size() + 1;
        produto.setId(novoId);
        listaProdutos.add(produto);
    }

    public void removerProduto(int id) {
        int posicao = id - 1;
        listaProdutos.remove(posicao);

        reorganizarIds();
        System.out.println("Produto removido.\n");
    }

    public void imprimirDadosProduto(int id) {
        int posicao = id - 1;
        listaProdutos.get(posicao).imprimirDados();
    }

    public void editarProduto(int id) {
        int posicao = id - 1;

        JDialog.setDefaultLookAndFeelDecorated(true);
        Object[] opcoes = {"Classificação", "Produto", "Preço"};
        String opcaoInicial = "Classificação";
        Object opcaoSelecionada = JOptionPane.showInputDialog(null, "O que você deseja editar?",
                "Edição de produto", JOptionPane.QUESTION_MESSAGE, null, opcoes, opcaoInicial);

        Produto produto = listaProdutos.get(posicao);

        switch (opcaoSelecionada.toString()) {
            case "Classificação":
                produto.setClassificacao(Integer.parseInt(JOptionPane.showInputDialog("Informe a nova classificação: ")));
                break;
            case "Produto":
                produto.setNome(JOptionPane.showInputDialog("Informe o novo nome: "));
                break;
            case "Preço":
                produto.setPreco(Double.parseDouble(JOptionPane.showInputDialog("Informe o novo preço: ")));
                break;
        }

        System.out.println("Produto editado: ");
        produto.imprimirDados();
    }

    public void listarProdutosCadastrados() {
        for (Produto produto : listaProdutos) {
            produto.imprimirDados();
            System.out.println();
        }
    }

    private void reorganizarIds() {
        for (int i = 0; i < listaProdutos.size(); i++) {
            listaProdutos.get(i).setId(i + 1);
        }
    }

    public static void menuProdutos() {
        CadProdutos cadastro = new CadProdutos();

        boolean executa = true;
        while (executa) {
            JDialog.setDefaultLookAndFeelDecorated(true);
            Object[] opcoes = {"Cadastrar produto", "Editar produto", "Remover produto", "Imprimir produto", "Listar produtos cadastrados", "Sair"};
            String opcaoInicial = "Cadastrar produto";
            Object opcaoSelecionada = JOptionPane.showInputDialog(null, "O que você deseja fazer?",
                    "Gestão de produtos", JOptionPane.QUESTION_MESSAGE, null, opcoes, opcaoInicial);

            if (opcaoSelecionada.equals("Cadastrar produto")) {
                Produto novoProduto = new Produto();
                novoProduto.setClassificacao(Integer.parseInt(JOptionPane.showInputDialog("Informe a classificação: ")));
                novoProduto.setNome(JOptionPane.showInputDialog("Informe o nome: "));
                novoProduto.setPreco(Double.parseDouble(JOptionPane.showInputDialog("Informe o preço: ")));

                cadastro.adicionarProduto(novoProduto);

                System.out.println("Produto cadastrado!\n");
                novoProduto.imprimirDados();
                System.out.println();
            } else if (opcaoSelecionada.equals("Editar produto")) {
                cadastro.editarProduto(Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do produto que deseja editar: ")));
            } else if (opcaoSelecionada.equals("Remover produto")) {
                cadastro.removerProduto(Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do produto que deseja remover: ")));
            } else if (opcaoSelecionada.equals("Imprimir produto")) {
                cadastro.imprimirDadosProduto(Integer.parseInt(JOptionPane.showInputDialog("Informe o ID do produto que deseja imprimir: ")));
            } else if (opcaoSelecionada.equals("Listar produtos cadastrados")) {
                cadastro.listarProdutosCadastrados();
            } else {
                executa = false;
                break;
            }
        }
    }

    public static void main(String[] args) {
        menuProdutos();
    }
}
