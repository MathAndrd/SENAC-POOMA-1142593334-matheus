package cad_produtos;

public class Produto {
		private int Id;
		private int Classificacao;
		private String nomeProduto;
		private double precoProduto;

		// Getters e Setters
		public int getId() {
			return Id;
		}
		public void setId(int id) {
			Id = id;
		}

	 

		
		public int getClassificacao() {
			return Classificacao;
		}
		public void setClassificacao(int classificacao) {
			Classificacao = classificacao;
		}

	 

		
		public String getNomeProduto() {
			return nomeProduto;
		}
		public void setNomeProduto(String nomeProduto) {
			this.nomeProduto = nomeProduto;
		}

	 

		
		public double getPrecoProduto() {
			return precoProduto;
		}
		public void setPrecoProduto(double precoProduto) {
			this.precoProduto = precoProduto;
		}
		


	}

