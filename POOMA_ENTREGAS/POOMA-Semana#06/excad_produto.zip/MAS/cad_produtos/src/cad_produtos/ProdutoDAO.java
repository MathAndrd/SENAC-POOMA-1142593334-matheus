package cad_produtos;

import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO<T extends Produto> {
    private List<T> produtos;

    public ProdutoDAO() {
        produtos = new ArrayList<>();
    }

    // Método para adicionar um produto
    public void adicionarProduto(T produto) {
        produtos.add(produto);
    }

    // Método para consultar um produto pelo ID
    public T consultarProduto(int id) {
        for (T produto : produtos) {
            if (produto.getId() == id) {
                return produto;
            }
        }
        return null; // Produto não encontrado
    }

    // Método para excluir um produto pelo ID
    public void excluirProduto(int id) {
        T produto = consultarProduto(id);
        if (produto != null) {
            produtos.remove(produto);
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    // Método para alterar um produto pelo ID
    public void alterarProduto(T produto) {
        int index = produtos.indexOf(produto);
        if (index != -1) {
            produtos.set(index, produto);
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    // Método para listar todos os produtos
    public List<T> listarProdutos() {
        return produtos;
    }
}
