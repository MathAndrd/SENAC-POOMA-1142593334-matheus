package cad_produtos;

import java.util.List;
import java.util.Scanner;

public class Teste {
    public static void main(String[] args) {
        ProdutoDAO<Produto> produtoDAO = new ProdutoDAO<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Escolha uma opção:");
            System.out.println("1 - Inclusão de produtos");
            System.out.println("2 - Consulta um determinado produto");
            System.out.println("3 - Excluir um determinado produto");
            System.out.println("4 - Alterar um determinado produto");
            System.out.println("5 - Listar todos os produtos");
            System.out.println("0 - Sair");

            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    // Inclusão de produtos
                    Produto produto = new Produto();
                    System.out.println("Digite o ID do produto:");
                    produto.setId(scanner.nextInt());
                    System.out.println("Digite a Classificação do produto:");
                    produto.setClassificacao(scanner.nextInt());
                    System.out.println("Digite o nome do produto:");
                    scanner.nextLine(); // Limpar o buffer do teclado
                    produto.setNomeProduto(scanner.nextLine());
                    System.out.println("Digite o preço do produto:");
                    produto.setPrecoProduto(scanner.nextDouble());

                    produtoDAO.adicionarProduto(produto);
                    System.out.println("Produto adicionado com sucesso.");
                    break;
                case 2:
                    // Consulta um determinado produto
                    System.out.println("Digite o ID do produto a ser consultado:");
                    int idConsulta = scanner.nextInt();
                    Produto produtoConsultado = produtoDAO.consultarProduto(idConsulta);
                    if (produtoConsultado != null) {
                        System.out.println("Produto encontrado:");
                        System.out.println("ID: " + produtoConsultado.getId());
                        System.out.println("Classificação: " + produtoConsultado.getClassificacao());
                        System.out.println("Nome: " + produtoConsultado.getNomeProduto());
                        System.out.println("Preço: " + produtoConsultado.getPrecoProduto());
                    } else {
                        System.out.println("Produto não encontrado.");
                    }
                    break;
                case 3:
                    // Excluir um determinado produto
                    System.out.println("Digite o ID do produto a ser excluído:");
                    int idExclusao = scanner.nextInt();
                    produtoDAO.excluirProduto(idExclusao);
                    System.out.println("Produto excluído com sucesso.");
                    break;
                case 4:
                    // Alterar um determinado produto
                    System.out.println("Digite o ID do produto a ser alterado:");
                    int idAlteracao = scanner.nextInt();
                    Produto produtoParaAlterar = produtoDAO.consultarProduto(idAlteracao);
                    if (produtoParaAlterar != null) {
                        System.out.println("Digite a nova Classificação:");
                        produtoParaAlterar.setClassificacao(scanner.nextInt());
                        System.out.println("Digite o novo nome:");
                        scanner.nextLine(); // Limpar o buffer do teclado
                        produtoParaAlterar.setNomeProduto(scanner.nextLine());
                        System.out.println("Digite o novo preço:");
                        produtoParaAlterar.setPrecoProduto(scanner.nextDouble());
                        produtoDAO.alterarProduto(produtoParaAlterar);
                        System.out.println("Produto alterado com sucesso.");
                    } else {
                        System.out.println("Produto não encontrado.");
                    }
                    break;
                case 5:
                    // Listar todos os produtos
                    List<Produto> produtos = produtoDAO.listarProdutos();
                    if (!produtos.isEmpty()) {
                        System.out.println("Lista de Produtos:");
                        for (Produto p : produtos) {
                            System.out.println("ID: " + p.getId());
                            System.out.println("Classificação: " + p.getClassificacao());
                            System.out.println("Nome: " + p.getNomeProduto());
                            System.out.println("Preço: " + p.getPrecoProduto());
                            System.out.println("-----------------------");
                        }
                    } else {
                        System.out.println("Nenhum produto cadastrado.");
                    }
                    break;
                case 0:
                    // Sair
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }
    }
}
