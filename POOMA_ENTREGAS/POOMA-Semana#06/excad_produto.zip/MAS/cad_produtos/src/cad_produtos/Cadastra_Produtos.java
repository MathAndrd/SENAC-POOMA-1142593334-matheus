package cad_produtos;

public class Cadastra_Produtos<T extends Produto>{

	private List<T> produtos;

	public Cadastra_Produtos() {
		produtos = new ArrayList<>();
	}
	
//método para adicionar produtos
	public void AdicionarProdutos(T produto) {
		produtos.add(produto);
	}
	
//método para consultar um produto pelo Id
	public T consultarProdutos(int Id) {
		for (T produto : produtos) {
			if (produto.getId() == Id) {
				return produto;
			}
		}
		return null; //produto não encontrado
	}
	
//método para remover produto
	public void excluirProdutos(int Id) {
		T produto = consultarProdutos(Id);
		if (produto != null) {
			produtos.remove(produto);
		} else {
			System.out.println("Produto não encontrado!");
		}
	}
	
//método para alterar um produto pelo Id
	public void alterarProduto(T produto) {
	int index = produtos.indexOf(produto);
	if (index != -1) {
		produtos.set(index, produto);
	} else {
		System.out.println("Produto não encontrado!");
	}
	}
	
    // Método para listar todos os produtos
    public List<T> listarProdutos() {
        return produtos;
    }
		
	}