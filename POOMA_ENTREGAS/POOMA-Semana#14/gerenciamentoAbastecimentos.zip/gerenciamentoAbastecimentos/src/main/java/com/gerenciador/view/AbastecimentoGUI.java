package main.java.com.gerenciador.view;

import main.java.com.gerenciador.controller.AbastecimentoController;
import main.java.com.gerenciador.model.Abastecimento;
import main.java.com.gerenciador.model.Veiculo;
import main.java.com.gerenciador.model.Posto;
import main.java.com.gerenciador.model.TipoCombustivel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;

import com.toedter.calendar.JDateChooser;

public class AbastecimentoGUI {
    private JFrame frame;
    private JComboBox<Veiculo> veiculoComboBox;
    private JComboBox<Posto> postoComboBox;
    private JComboBox<TipoCombustivel> combustivelComboBox;
    private JDateChooser dataAbastecimentoChooser;
    private JTextField litrosAbastecidosField, valorTotalField, distanciaMediaPorLitroField;
    private AbastecimentoController abastecimentoController;
    private int abastecimentoId;
    private double valorTotalCalculado;
    private double distanciaMediaPorLitroCalculada;

    public AbastecimentoGUI(AbastecimentoController abastecimentoController) {
        this.abastecimentoController = abastecimentoController;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cadastro de Abastecimento");
        frame.setBounds(100, 100, 800, 300);

        JPanel panel = new JPanel(new GridLayout(8, 2));
        frame.getContentPane().add(panel);

        panel.add(new JLabel("Veículo:"));
        veiculoComboBox = new JComboBox<>();
        carregarVeiculos();
        panel.add(veiculoComboBox);

        panel.add(new JLabel("Posto:"));
        postoComboBox = new JComboBox<>();
        carregarPostos();
        panel.add(postoComboBox);

        panel.add(new JLabel("Combustível:"));
        combustivelComboBox = new JComboBox<>();
        carregarCombustiveis();
        panel.add(combustivelComboBox);

        panel.add(new JLabel("Data Abastecimento:"));
        dataAbastecimentoChooser = new JDateChooser();
        panel.add(dataAbastecimentoChooser);

        panel.add(new JLabel("Litros Abastecidos:"));
        litrosAbastecidosField = new JTextField();
        panel.add(litrosAbastecidosField);

        panel.add(new JLabel("Valor total do abastecimento (R$):"));
        valorTotalField = new JTextField();
        valorTotalField.setEditable(false);
        panel.add(valorTotalField);

        panel.add(new JLabel("Distância percorrida prevista após abastecimento (KM):"));
        distanciaMediaPorLitroField = new JTextField();
        distanciaMediaPorLitroField.setEditable(false);
        panel.add(distanciaMediaPorLitroField);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cadastrarAbastecimento();
            }
        });
        panel.add(cadastrarButton);

        JButton calcularButton = new JButton("Calcular");
        calcularButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calcularCampos();
            }
        });
        panel.add(calcularButton);

        frame.setVisible(false); // Inicia como oculto, será exibido quando selecionar a opção de Cadastros
    }

    private void carregarVeiculos() {
        try {
            List<Veiculo> veiculos = abastecimentoController.getVeiculos();
            for (Veiculo veiculo : veiculos) {
                veiculoComboBox.addItem(veiculo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void carregarPostos() {
        try {
            List<Posto> postos = abastecimentoController.getPostos();
            for (Posto posto : postos) {
                postoComboBox.addItem(posto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void carregarCombustiveis() {
        try {
            List<TipoCombustivel> combustiveis = abastecimentoController.getCombustiveis();
            for (TipoCombustivel combustivel : combustiveis) {
                combustivelComboBox.addItem(combustivel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void exibir() {
        frame.setVisible(true);
    }

    private void cadastrarAbastecimento() {
        try {
            Veiculo veiculoSelecionado = (Veiculo) veiculoComboBox.getSelectedItem();
            Posto postoSelecionado = (Posto) postoComboBox.getSelectedItem();
            TipoCombustivel combustivelSelecionado = (TipoCombustivel) combustivelComboBox.getSelectedItem();

            java.util.Date dataAbastecimento = dataAbastecimentoChooser.getDate();
            java.sql.Date dataAbastecimentoSQL = new Date(dataAbastecimento.getTime());
            double litrosAbastecidos = Double.parseDouble(litrosAbastecidosField.getText());

            abastecimentoController.cadastrarAbastecimento(veiculoSelecionado.getId(), postoSelecionado.getId(),
                    combustivelSelecionado.getId(), dataAbastecimentoSQL,
                    litrosAbastecidos, valorTotalCalculado, distanciaMediaPorLitroCalculada);

            // Exibir mensagem de sucesso
            JOptionPane.showMessageDialog(frame, "Cadastro de abastecimento realizado com sucesso.", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            // Limpar campos
            litrosAbastecidosField.setText("");
            dataAbastecimentoChooser.setDate(null);
            valorTotalField.setText("");
            distanciaMediaPorLitroField.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira valores válidos.");
        }
    }

    private void calcularCampos() {
        try {
            Veiculo veiculoSelecionado = (Veiculo) veiculoComboBox.getSelectedItem();
            TipoCombustivel combustivelSelecionado = (TipoCombustivel) combustivelComboBox.getSelectedItem();

            double litrosAbastecidos = Double.parseDouble(litrosAbastecidosField.getText());

            DecimalFormat decimalFormat = new DecimalFormat("#.##");

            BigDecimal valorTotal = BigDecimal.valueOf(litrosAbastecidos).multiply(BigDecimal.valueOf(combustivelSelecionado.getPrecoPorLitro()));
            BigDecimal distanciaMedia = BigDecimal.valueOf(litrosAbastecidos).multiply(BigDecimal.valueOf(veiculoSelecionado.getKmPorLitro()));

            valorTotal = valorTotal.setScale(2, RoundingMode.HALF_UP);
            distanciaMedia = distanciaMedia.setScale(2, RoundingMode.HALF_UP);

            valorTotalCalculado = valorTotal.doubleValue();
            distanciaMediaPorLitroCalculada = distanciaMedia.doubleValue();

            valorTotalField.setText(String.valueOf(decimalFormat.format(valorTotalCalculado)));
            distanciaMediaPorLitroField.setText(String.valueOf(distanciaMediaPorLitroCalculada));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira valores válidos.");
        }
    }

    public void exibirListaAbastecimentos(String colunaOrdenacao, String tipoOrdem) {
        List<Abastecimento> abastecimentos = abastecimentoController.listarAbastecimentos(colunaOrdenacao, tipoOrdem);

        String[] colunas = {"ID", "Data", "Litros", "Valor Total", "Distância Média",
                "Veículo (Placa)", "Veículo (Marca)", "Veículo (Modelo)",
                "Posto (Nome)", "Posto (Local)",
                "Combustível (Nome)", "Combustível (Tipo)", "Combustível (Valor)"};

        DefaultTableModel model = new DefaultTableModel(colunas, 0);

        for (Abastecimento abastecimento : abastecimentos) {
            // Adicione uma nova linha para cada abastecimento
            Object[] row = {
                    abastecimento.getId(),
                    abastecimento.getDataAbastecimento(),
                    abastecimento.getLitrosAbastecidos(),
                    abastecimento.getValorTotal(),
                    abastecimento.getDistanciaMediaPorLitro(),
                    abastecimento.getVeiculo().getPlaca(),
                    abastecimento.getVeiculo().getMarca(),
                    abastecimento.getVeiculo().getModelo(),
                    abastecimento.getPosto().getNome(),
                    abastecimento.getPosto().getLocal(),
                    abastecimento.getTipoCombustivel().getNome(),
                    abastecimento.getTipoCombustivel().getTipo(),
                    abastecimento.getTipoCombustivel().getPrecoPorLitro()
            };
            model.addRow(row);
        }

        JTable tabelaAbastecimentos = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(tabelaAbastecimentos);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        panel.setPreferredSize(new Dimension(screenSize.width, screenSize.height));

        JFrame frame = new JFrame("Lista de Abastecimentos");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        frame.getContentPane().add(panel);

        frame.pack();
        frame.setVisible(true);
    }
}
