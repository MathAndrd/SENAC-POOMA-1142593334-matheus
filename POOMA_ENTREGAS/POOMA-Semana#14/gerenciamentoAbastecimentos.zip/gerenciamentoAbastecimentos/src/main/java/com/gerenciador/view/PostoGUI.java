// PostoGUI.java
package main.java.com.gerenciador.view;

import main.java.com.gerenciador.controller.PostoController;
import main.java.com.gerenciador.model.Posto;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PostoGUI {
    private JFrame frame;
    private JTextField nomeField, localField;
    private PostoController postoController;
    private int postoId;

    public PostoGUI(PostoController postoController) {
        this.postoController = postoController;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cadastro de Posto");
        frame.setBounds(100, 100, 400, 200);

        JPanel panel = new JPanel(new GridLayout(6, 1));
        frame.getContentPane().add(panel);

        panel.add(new JLabel("Nome:"));
        nomeField = new JTextField();
        panel.add(nomeField);

        panel.add(new JLabel("Local:"));
        localField = new JTextField();
        panel.add(localField);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cadastrarPosto();
            }
        });
        panel.add(cadastrarButton);

        JButton atualizarButton = new JButton("Atualizar");

        atualizarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                atualizarPosto();
            }
        });
        panel.add(atualizarButton);

        frame.setVisible(false); // Inicia como oculto, será exibido quando selecionar a opção de Cadastros
    }

    public void exibir() {
        frame.setVisible(true);
    }

    private void cadastrarPosto() {
        String nome = nomeField.getText();
        String local = localField.getText();

        postoController.cadastrarPosto(nome, local);

        // Limpar os campos após cadastrar
        nomeField.setText("");
        localField.setText("");
    }

    private void atualizarPosto() {
        try{
            int id = postoId;
            String nome = nomeField.getText();
            String local = localField.getText();

            postoController.atualizarPosto(id, nome, local);

            // Limpar após atualizar
            this.postoId = 0;
            nomeField.setText("");
            localField.setText("");
        } catch (NumberFormatException ex){
            JOptionPane.showMessageDialog(frame, "Por favor, insira um ID válido para atualizar.");
        }
    }

    public void preencherCampos(Posto posto) {
        this.postoId = posto.getId();

        nomeField.setText(posto.getNome());
        localField.setText(posto.getLocal());
    }

}
