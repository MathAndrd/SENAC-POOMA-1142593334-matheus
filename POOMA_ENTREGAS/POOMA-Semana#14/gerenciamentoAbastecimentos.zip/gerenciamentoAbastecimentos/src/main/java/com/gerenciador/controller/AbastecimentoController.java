package main.java.com.gerenciador.controller;

import main.java.com.gerenciador.dao.AbastecimentoDAO;
import main.java.com.gerenciador.model.Abastecimento;
import main.java.com.gerenciador.model.Posto;
import main.java.com.gerenciador.model.TipoCombustivel;
import main.java.com.gerenciador.model.Veiculo;
import main.java.com.gerenciador.view.AbastecimentoGUI;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AbastecimentoController {
    private AbastecimentoDAO abastecimentoDAO;
    private VeiculoController veiculoController;
    private PostoController postoController;
    private TipoCombustivelController tipoCombustivelController;
    private Connection connection;
    private AbastecimentoGUI abastecimentoGUI;

    public AbastecimentoController(Connection connection) {
        this.connection = connection;
        this.abastecimentoDAO = new AbastecimentoDAO(connection);
        this.veiculoController = new VeiculoController(connection);
        this.postoController = new PostoController(connection);
        this.tipoCombustivelController = new TipoCombustivelController(connection);
        this.abastecimentoGUI = new AbastecimentoGUI(this);
    }


    public void cadastrarAbastecimento(int idVeiculo, int idPosto, int idCombustivel,
                                       Date dataAbastecimento, double litrosAbastecidos,
                                       double valorTotal, double distanciaMediaPorLitro) {
        try {
            Abastecimento abastecimento = new Abastecimento(0, idVeiculo, idPosto, idCombustivel,
                    dataAbastecimento, litrosAbastecidos, valorTotal, distanciaMediaPorLitro);
            abastecimentoDAO.inserirAbastecimento(abastecimento);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cadastrarAbastecimento(Abastecimento abastecimento) throws SQLException {
        abastecimentoDAO.inserirAbastecimento(abastecimento);
    }

    public List<Abastecimento> listarAbastecimentos(String colunaOrdenacao, String tipoOrdem) {
        try {
            return abastecimentoDAO.listarAbastecimentos(colunaOrdenacao, tipoOrdem);
        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    public void atualizarAbastecimento(int abastecimentoId, int idVeiculo, int idPosto, int idCombustivel,
                                       Date dataAbastecimento, double litrosAbastecidos,
                                       double valorTotal, double distanciaMediaPorLitro) {
        try {
            Abastecimento abastecimento = new Abastecimento(abastecimentoId, idVeiculo, idPosto, idCombustivel,
                    dataAbastecimento, litrosAbastecidos, valorTotal, distanciaMediaPorLitro);
            abastecimentoDAO.atualizarAbastecimento(abastecimento);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirAbastecimento(int abastecimentoId) {
        try {
            abastecimentoDAO.excluirAbastecimento(abastecimentoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Abastecimento buscarAbastecimentoPorId(int abastecimentoId) {
        try {
            return abastecimentoDAO.buscarAbastecimentoPorId(abastecimentoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Veiculo> getVeiculos() throws SQLException {
        return veiculoController.listaVeiculos();
    }

    public List<Posto> getPostos() throws SQLException {
        return postoController.listaPostos();
    }

    public List<TipoCombustivel> getCombustiveis() throws SQLException {
        return tipoCombustivelController.listarTiposCombustivel();
    }
}
