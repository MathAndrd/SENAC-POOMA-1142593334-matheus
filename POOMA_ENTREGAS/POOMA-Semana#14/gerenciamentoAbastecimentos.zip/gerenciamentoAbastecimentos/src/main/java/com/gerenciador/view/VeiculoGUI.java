package main.java.com.gerenciador.view;

import main.java.com.gerenciador.controller.VeiculoController;
import main.java.com.gerenciador.model.Veiculo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VeiculoGUI {
    private JFrame frame;
    private JTextField marcaField, modeloField, placaField, renavamField, consumoField;
    private VeiculoController veiculoController;
    private int veiculoId;

    public VeiculoGUI(VeiculoController veiculoController) {
        this.veiculoController = veiculoController;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cadastro de Veículo");
        frame.setBounds(100, 100, 400, 300);

        JPanel panel = new JPanel(new GridLayout(8, 1));
        frame.getContentPane().add(panel);

        panel.add(new JLabel("Marca:"));
        marcaField = new JTextField();
        panel.add(marcaField);

        panel.add(new JLabel("Modelo:"));
        modeloField = new JTextField();
        panel.add(modeloField);

        panel.add(new JLabel("Placa:"));
        placaField = new JTextField();
        panel.add(placaField);

        panel.add(new JLabel("Renavam:"));
        renavamField = new JTextField();
        panel.add(renavamField);

        panel.add(new JLabel("Km/litro:"));
        consumoField = new JTextField();
        panel.add(consumoField);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cadastrarVeiculo();
            }
        });
        panel.add(cadastrarButton);

        JButton atualizarButton = new JButton("Atualizar");

        atualizarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                atualizarVeiculo();
            }
        });
        panel.add(atualizarButton);

        frame.setVisible(false); // Inicia como oculto, será exibido quando selecionar a opção de Cadastros
    }

    public void exibir() {
        frame.setVisible(true);
    }

    private void cadastrarVeiculo() {
        String marca = marcaField.getText();
        String modelo = modeloField.getText();
        String placa = placaField.getText();
        String renavam = renavamField.getText();
        double consumoPorLitro = Double.parseDouble(consumoField.getText());

        veiculoController.cadastrarVeiculo(marca, modelo, placa, renavam, consumoPorLitro);

        // Limpar os campos após cadastrar
        marcaField.setText("");
        modeloField.setText("");
        placaField.setText("");
        renavamField.setText("");
        consumoField.setText("");
    }

    private void atualizarVeiculo() {
        try {
            int id = veiculoId;
            String marca = marcaField.getText();
            String modelo = modeloField.getText();
            String placa = placaField.getText();
            String renavam = renavamField.getText();
            double consumoPorLitro = Double.parseDouble(consumoField.getText());

            veiculoController.atualizarVeiculo(id, marca, modelo, placa, renavam, consumoPorLitro);

            // Limpar os campos após atualizar
            this.veiculoId = 0;
            marcaField.setText("");
            modeloField.setText("");
            placaField.setText("");
            renavamField.setText("");
            consumoField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira um ID válido para atualizar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void preencherCampos(Veiculo veiculo) {
        this.veiculoId = veiculo.getId();

        marcaField.setText(veiculo.getMarca());
        modeloField.setText(veiculo.getModelo());
        placaField.setText(veiculo.getPlaca());
        renavamField.setText(veiculo.getRenavam());
        consumoField.setText(Double.toString(veiculo.getKmPorLitro()));
    }

}
