package main.java.com.gerenciador.dao;

import main.java.com.gerenciador.model.TipoCombustivel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoCombustivelDAO {
    private Connection connection;

    public TipoCombustivelDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para inserir um tipo de combustível no banco de dados
    public void inserirTipoCombustivel(TipoCombustivel tipoCombustivel) throws SQLException {
        String sql = "INSERT INTO tipo_combustivel (nome, tipo, precoPorLitro) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, tipoCombustivel.getNome());
            statement.setString(2, tipoCombustivel.getTipo());
            statement.setDouble(3, tipoCombustivel.getPrecoPorLitro());
            statement.executeUpdate();
        }
    }

    public List<TipoCombustivel> listarTiposCombustivel() throws SQLException {
        List<TipoCombustivel> tiposCombustivel = new ArrayList<>();
        String sql = "SELECT * FROM tipo_combustivel";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                TipoCombustivel tipoCombustivel = new TipoCombustivel();
                tipoCombustivel.setId(resultSet.getInt("id"));
                tipoCombustivel.setNome(resultSet.getString("nome"));
                tipoCombustivel.setTipo(resultSet.getString("tipo"));
                tipoCombustivel.setPrecoPorLitro(resultSet.getDouble("precoPorLitro"));
                tiposCombustivel.add(tipoCombustivel);
            }
        }
        return tiposCombustivel;
    }

    public void atualizarTipoCombustivel(TipoCombustivel tipoCombustivel) throws SQLException {
        String sql = "UPDATE tipo_combustivel SET nome=?, tipo=?, precoPorLitro=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, tipoCombustivel.getNome());
            statement.setString(2, tipoCombustivel.getTipo());
            statement.setDouble(3, tipoCombustivel.getPrecoPorLitro());
            statement.setInt(4, tipoCombustivel.getId());
            statement.executeUpdate();
        }
    }

    public void excluirTipoCombustivel(int tipoCombustivelId) throws SQLException {
        String sql = "DELETE FROM tipo_combustivel WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, tipoCombustivelId);
            statement.executeUpdate();
        }
    }

    public TipoCombustivel buscarTipoCombustivelPorId(int tipoCombustivelId) throws SQLException {
        String sql = "SELECT * FROM tipo_combustivel WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, tipoCombustivelId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    TipoCombustivel tipoCombustivel = new TipoCombustivel();
                    tipoCombustivel.setId(resultSet.getInt("id"));
                    tipoCombustivel.setNome(resultSet.getString("nome"));
                    tipoCombustivel.setTipo(resultSet.getString("tipo"));
                    tipoCombustivel.setPrecoPorLitro(resultSet.getDouble("precoPorLitro"));
                    return tipoCombustivel;
                }
            }
        }
        return null;
    }

    public List<String> listarNomesTiposCombustivel() throws SQLException {
        List<String> nomesTiposCombustivel = new ArrayList<>();
        String sql = "SELECT nome FROM tipo_combustivel";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                nomesTiposCombustivel.add(resultSet.getString("nome"));
            }
        }
        return nomesTiposCombustivel;
    }

}

