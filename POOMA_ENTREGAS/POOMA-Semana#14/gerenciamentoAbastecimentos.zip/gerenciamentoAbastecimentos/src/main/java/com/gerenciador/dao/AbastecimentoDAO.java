package main.java.com.gerenciador.dao;

import main.java.com.gerenciador.model.Abastecimento;
import main.java.com.gerenciador.model.Posto;
import main.java.com.gerenciador.model.TipoCombustivel;
import main.java.com.gerenciador.model.Veiculo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AbastecimentoDAO {
    private Connection connection;

    public AbastecimentoDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para inserir um abastecimento no banco de dados
    public void inserirAbastecimento(Abastecimento abastecimento) throws SQLException {
        String sql = "INSERT INTO abastecimento (id_veiculo, id_posto, id_combustivel, " +
                "data_abastecimento, litros_abastecidos, valor_total, distancia_media_por_litro) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, abastecimento.getIdVeiculo());
            statement.setInt(2, abastecimento.getIdPosto());
            statement.setInt(3, abastecimento.getIdCombustivel());
            statement.setDate(4, abastecimento.getDataAbastecimento());
            statement.setDouble(5, abastecimento.getLitrosAbastecidos());
            statement.setDouble(6, abastecimento.getValorTotal());
            statement.setDouble(7, abastecimento.getDistanciaMediaPorLitro());
            statement.executeUpdate();
        }
    }

    // Método para buscar todos os abastecimentos no banco de dados
    public List<Abastecimento> listarAbastecimentos(String colunaOrdenacao, String tipoOrdem) throws SQLException {
        List<Abastecimento> abastecimentos = new ArrayList<>();

        String sql = "SELECT abastecimento.id, abastecimento.data_abastecimento, abastecimento.litros_abastecidos, abastecimento.valor_total, " +
                "abastecimento.distancia_media_por_litro, " +
                "veiculo.placa, veiculo.marca, veiculo.modelo, posto.nome AS posto_nome, posto.local AS posto_local, " +
                "tipo_combustivel.nome AS combustivel_nome, " +
                "tipo_combustivel.tipo AS combustivel_tipo, " +
                "tipo_combustivel.precoPorLitro AS combustivel_preco_un " +
                "FROM abastecimento " +
                "LEFT JOIN veiculo ON abastecimento.id_veiculo = veiculo.id " +
                "LEFT JOIN posto ON abastecimento.id_posto = posto.id " +
                "LEFT JOIN tipo_combustivel ON abastecimento.id_combustivel = tipo_combustivel.id " +
                "ORDER BY " + colunaOrdenacao + " " + tipoOrdem;


        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                // Mapear os resultados para um objeto Abastecimento
                Abastecimento abastecimento = new Abastecimento();
                abastecimento.setId(resultSet.getInt("id"));
                abastecimento.setDataAbastecimento(resultSet.getDate("data_abastecimento"));
                abastecimento.setLitrosAbastecidos(resultSet.getDouble("litros_abastecidos"));
                abastecimento.setValorTotal(resultSet.getDouble("valor_total"));
                abastecimento.setDistanciaMediaPorLitro(resultSet.getDouble("distancia_media_por_litro"));

                // Mapear informações do veículo
                Veiculo veiculo = new Veiculo();
                veiculo.setPlaca(resultSet.getString("placa"));
                veiculo.setMarca(resultSet.getString("marca"));
                veiculo.setModelo(resultSet.getString("modelo"));
                abastecimento.setVeiculo(veiculo);

                // Mapear informações do posto
                Posto posto = new Posto();
                posto.setNome(resultSet.getString("posto_nome"));
                posto.setLocal(resultSet.getString("posto_local"));
                abastecimento.setPosto(posto);

                // Mapear informações do tipo de combustível
                TipoCombustivel tipoCombustivel = new TipoCombustivel();
                tipoCombustivel.setNome(resultSet.getString("combustivel_nome"));
                tipoCombustivel.setTipo(resultSet.getString("combustivel_tipo"));
                tipoCombustivel.setPrecoPorLitro(resultSet.getDouble("combustivel_preco_un"));
                abastecimento.setTipoCombustivel(tipoCombustivel);

                abastecimentos.add(abastecimento);
            }
        }

        return abastecimentos;
    }

    // Método para atualizar um abastecimento no banco de dados
    public void atualizarAbastecimento(Abastecimento abastecimento) throws SQLException {
        String sql = "UPDATE abastecimento SET id_veiculo=?, id_posto=?, id_combustivel=?, " +
                "data_abastecimento=?, litros_abastecidos=?, valor_total=?, " +
                "distancia_media_por_litro=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, abastecimento.getIdVeiculo());
            statement.setInt(2, abastecimento.getIdPosto());
            statement.setInt(3, abastecimento.getIdCombustivel());
            statement.setDate(4, abastecimento.getDataAbastecimento());
            statement.setDouble(5, abastecimento.getLitrosAbastecidos());
            statement.setDouble(6, abastecimento.getValorTotal());
            statement.setDouble(7, abastecimento.getDistanciaMediaPorLitro());
            statement.setInt(8, abastecimento.getId());
            statement.executeUpdate();
        }
    }

    // Método para excluir um abastecimento do banco de dados
    public void excluirAbastecimento(int abastecimentoId) throws SQLException {
        String sql = "DELETE FROM abastecimento WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, abastecimentoId);
            statement.executeUpdate();
        }
    }

    // Método para buscar um abastecimento por ID
    public Abastecimento buscarAbastecimentoPorId(int abastecimentoId) throws SQLException {
        String sql = "SELECT * FROM abastecimento WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, abastecimentoId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Abastecimento abastecimento = new Abastecimento();
                    abastecimento.setId(resultSet.getInt("id"));
                    abastecimento.setIdVeiculo(resultSet.getInt("id_veiculo"));
                    abastecimento.setIdPosto(resultSet.getInt("id_posto"));
                    abastecimento.setIdCombustivel(resultSet.getInt("id_combustivel"));
                    abastecimento.setDataAbastecimento(resultSet.getDate("data_abastecimento"));
                    abastecimento.setLitrosAbastecidos(resultSet.getDouble("litros_abastecidos"));
                    abastecimento.setValorTotal(resultSet.getDouble("valor_total"));
                    abastecimento.setDistanciaMediaPorLitro(resultSet.getDouble("distancia_media_por_litro"));
                    return abastecimento;
                }
            }
        }
        return null;
    }
}
