package main.java.com.gerenciador.dao;

import main.java.com.gerenciador.model.Posto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PostoDAO {
    private Connection connection;
    public PostoDAO(Connection connection) { this.connection = connection; }

    public void cadastrarPosto(Posto posto) throws SQLException {
        String sql = "INSERT INTO posto (nome, local) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, posto.getNome());
            statement.setString(2, posto.getLocal());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Posto> listarPostos() throws SQLException {
        List<Posto> postos = new ArrayList<>();
        String sql = "SELECT * FROM posto";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Posto posto = new Posto();
                posto.setId(resultSet.getInt("id"));
                posto.setNome(resultSet.getString("nome"));
                posto.setLocal(resultSet.getString("local"));
                postos.add(posto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return postos;
    }

    public void atualizarPosto(Posto posto) throws SQLException{
        String sql = "UPDATE posto SET nome=?, local=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, posto.getNome());
            statement.setString(2, posto.getLocal());
            statement.setInt(3, posto.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirPosto(int postoId) throws SQLException {
        String sql = "DELETE FROM posto WHERE id=?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, postoId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Posto buscarPostoPorId(int postoId) throws SQLException {
        String sql = "SELECT * FROM posto WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, postoId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Posto posto = new Posto();
                    posto.setId(resultSet.getInt("id"));
                    posto.setNome(resultSet.getString("nome"));
                    posto.setLocal(resultSet.getString("local"));
                    return posto;
                }
            }
        }
        return null;
    }

    public List<String> listarNomesPostos() throws SQLException {
        List<String> nomesPostos = new ArrayList<>();
        String sql = "SELECT nome FROM posto";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                nomesPostos.add(resultSet.getString("nome"));
            }
        }
        return nomesPostos;
    }


}

