package main.java.com.gerenciador;

import main.java.com.gerenciador.database.DatabaseInitializer;
import main.java.com.gerenciador.view.TelaPrincipal;

import javax.swing.*;

public class App {
    public static void main(String[] args) {
        // Inicializa o banco de dados
        DatabaseInitializer.createDatabaseAndTables();

        // Cria a tela principal
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    new TelaPrincipal();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
