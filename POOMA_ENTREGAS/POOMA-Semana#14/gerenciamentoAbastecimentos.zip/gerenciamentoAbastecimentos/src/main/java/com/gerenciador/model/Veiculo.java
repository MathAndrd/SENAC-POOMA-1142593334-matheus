package  main.java.com.gerenciador.model;

public class Veiculo {
    private int id;
    private String marca;
    private String modelo;
    private String placa;
    private String renavam;
    private double kmPorLitro;

    // Construtores
    public Veiculo() {
    }

    public Veiculo(int id, String marca, String modelo, String placa, String renavam, double kmPorLitro) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.placa = placa;
        this.renavam = renavam;
        this.kmPorLitro = kmPorLitro;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public double getKmPorLitro() {
        return kmPorLitro;
    }

    public void setKmPorLitro(double kmPorLitro) {
        this.kmPorLitro = kmPorLitro;
    }

    @Override
    public String toString() {
        return String.format("%s | %s | %s", getPlaca(), getMarca(), getModelo());
    }

}
