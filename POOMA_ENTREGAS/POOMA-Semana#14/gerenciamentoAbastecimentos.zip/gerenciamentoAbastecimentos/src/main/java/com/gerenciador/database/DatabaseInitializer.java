package main.java.com.gerenciador.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {
    private static final String DATABASE_NAME = "app_postos";

    public static void createDatabaseAndTables() {
        try (Connection connection = ConnectionFactory.createConnection();
             Statement statement = connection.createStatement()) {

            String createDatabase = "CREATE DATABASE IF NOT EXISTS " + DATABASE_NAME;
            statement.executeUpdate(createDatabase);

            // Seleciona o banco de dados recém-criado ou já existente
            String useDatabase = "USE " + DATABASE_NAME;
            statement.executeUpdate(useDatabase);

            // Criação da tabela veiculo
            String createVeiculoTable = "CREATE TABLE IF NOT EXISTS veiculo (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "marca VARCHAR(255) NOT NULL," +
                    "modelo VARCHAR(255) NOT NULL," +
                    "placa VARCHAR(20) NOT NULL," +
                    "renavam VARCHAR(20) NOT NULL," +
                    "kmPorLitro DOUBLE NOT NULL" +
                    ")";
            statement.executeUpdate(createVeiculoTable);

            // Criação da tabela posto
            String createPostoTable = "CREATE TABLE IF NOT EXISTS posto (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "nome VARCHAR(255) NOT NULL," +
                    "local VARCHAR(255) NOT NULL" +
                    ")";
            statement.executeUpdate(createPostoTable);

            // Criação da tabela tipo_combustivel
            String createTipoCombustivelTable = "CREATE TABLE IF NOT EXISTS tipo_combustivel (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "nome VARCHAR(255) NOT NULL," +
                    "tipo VARCHAR(255) NOT NULL," +
                    "precoPorLitro DOUBLE NOT NULL" +
                    ")";
            statement.executeUpdate(createTipoCombustivelTable);

            // Criação da tabela abastecimento
            String createAbastecimentoTable = "CREATE TABLE IF NOT EXISTS abastecimento (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "id_veiculo INT," +
                    "id_posto INT," +
                    "id_combustivel INT," +
                    "data_abastecimento DATE NOT NULL," +
                    "litros_abastecidos DOUBLE NOT NULL," +
                    "valor_total DOUBLE NOT NULL," +
                    "distancia_media_por_litro DOUBLE NOT NULL," +
                    "FOREIGN KEY (id_veiculo) REFERENCES veiculo(id)," +
                    "FOREIGN KEY (id_posto) REFERENCES posto(id)," +
                    "FOREIGN KEY (id_combustivel) REFERENCES tipo_combustivel(id)" +
                    ")";
            statement.executeUpdate(createAbastecimentoTable);

            System.out.println("Banco de dados e tabelas criados com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Erro ao criar banco de dados e tabelas: " + e.getMessage());
        }
    }
}
