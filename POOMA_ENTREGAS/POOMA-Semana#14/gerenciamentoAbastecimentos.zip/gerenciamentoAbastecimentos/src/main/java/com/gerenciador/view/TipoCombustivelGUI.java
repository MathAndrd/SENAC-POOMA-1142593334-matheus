package main.java.com.gerenciador.view;

import main.java.com.gerenciador.controller.TipoCombustivelController;
import main.java.com.gerenciador.model.TipoCombustivel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TipoCombustivelGUI {
    private JFrame frame;
    private JTextField nomeField, tipoField, precoField;
    private TipoCombustivelController tipoCombustivelController;
    private int tipoCombustivelId;

    public TipoCombustivelGUI(TipoCombustivelController tipoCombustivelController) {
        this.tipoCombustivelController = tipoCombustivelController;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cadastro de Tipo de Combustível");
        frame.setBounds(100, 100, 400, 200);

        JPanel panel = new JPanel(new GridLayout(5, 1));
        frame.getContentPane().add(panel);

        panel.add(new JLabel("Nome:"));
        nomeField = new JTextField();
        panel.add(nomeField);

        panel.add(new JLabel("Tipo:"));
        tipoField = new JTextField();
        panel.add(tipoField);

        panel.add(new JLabel("Preço por Litro:"));
        precoField = new JTextField();
        panel.add(precoField);

        JButton cadastrarButton = new JButton("Cadastrar");
        cadastrarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cadastrarTipoCombustivel();
            }
        });
        panel.add(cadastrarButton);

        JButton atualizarButton = new JButton("Atualizar");

        atualizarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                atualizarTipoCombustivel();
            }
        });
        panel.add(atualizarButton);

        frame.setVisible(false); // Inicia como oculto, será exibido quando selecionar a opção de Cadastros
    }

    public void exibir() {
        frame.setVisible(true);
    }

    private void cadastrarTipoCombustivel() {
        String nome = nomeField.getText();
        String tipo = tipoField.getText();
        double precoPorLitro = Double.parseDouble(precoField.getText());

        tipoCombustivelController.cadastrarTipoCombustivel(nome, tipo, precoPorLitro);

        // Limpar os campos após cadastrar
        nomeField.setText("");
        tipoField.setText("");
        precoField.setText("");
    }

    private void atualizarTipoCombustivel() {
        try {
            int id = tipoCombustivelId;
            String nome = nomeField.getText();
            String tipo = tipoField.getText();
            double precoPorLitro = Double.parseDouble(precoField.getText());

            tipoCombustivelController.atualizarTipoCombustivel(id, nome, tipo, precoPorLitro);

            // Limpar os campos após atualizar
            this.tipoCombustivelId = 0;
            nomeField.setText("");
            tipoField.setText("");
            precoField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Por favor, insira um ID válido para atualizar.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void preencherCampos(TipoCombustivel tipoCombustivel) {
        this.tipoCombustivelId = tipoCombustivel.getId();

        nomeField.setText(tipoCombustivel.getNome());
        tipoField.setText(tipoCombustivel.getTipo());
        precoField.setText(Double.toString(tipoCombustivel.getPrecoPorLitro()));
    }
}
