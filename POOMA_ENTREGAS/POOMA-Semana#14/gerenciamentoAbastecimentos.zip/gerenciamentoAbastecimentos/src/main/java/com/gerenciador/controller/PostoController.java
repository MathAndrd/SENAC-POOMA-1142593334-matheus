package main.java.com.gerenciador.controller;

import main.java.com.gerenciador.dao.PostoDAO;
import main.java.com.gerenciador.model.Posto;
import main.java.com.gerenciador.view.PostoGUI;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class PostoController {
    private PostoDAO postoDAO;
    private PostoGUI postoGUI;

    public PostoController(Connection connection) {
        this.postoDAO = new PostoDAO(connection);
        this.postoGUI = new PostoGUI(this);
    }

    public void cadastrarPosto(String nome, String local) {
        try {
            Posto posto = new Posto(0, nome, local);
            postoDAO.cadastrarPosto(posto);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Posto> listaPostos() {
        try {
            return postoDAO.listarPostos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void atualizarPosto(int postoId, String nome, String local) {
        try {
            Posto posto = new Posto(postoId, nome, local);
            postoDAO.atualizarPosto(posto);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirPosto(int postoId) {
        try {
            postoDAO.excluirPosto(postoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Posto buscarPostoPorId(int postoId) {
        try {
            return postoDAO.buscarPostoPorId(postoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String> getNomesPostos() throws SQLException {
        return postoDAO.listarNomesPostos();
    }

}
