package main.java.com.gerenciador.model;

import main.java.com.gerenciador.controller.TipoCombustivelController;
import main.java.com.gerenciador.controller.VeiculoController;

import java.sql.Date;

public class Abastecimento {
    private int id;
    private int idVeiculo;
    private int idPosto;
    private int idCombustivel;
    private Date dataAbastecimento;
    private double litrosAbastecidos;
    private double valorTotal;
    private double distanciaMediaPorLitro;
    private Veiculo veiculo;
    private Posto posto;
    private TipoCombustivel tipoCombustivel;

    // Construtores
    public Abastecimento() {
    }

    public Abastecimento(int id, int idVeiculo, int idPosto, int idCombustivel,
                         Date dataAbastecimento, double litrosAbastecidos,
                         double valorTotal, double distanciaMediaPorLitro) {
        this.id = id;
        this.idVeiculo = idVeiculo;
        this.idPosto = idPosto;
        this.idCombustivel = idCombustivel;
        this.dataAbastecimento = dataAbastecimento;
        this.litrosAbastecidos = litrosAbastecidos;
        this.valorTotal = valorTotal;
        this.distanciaMediaPorLitro = distanciaMediaPorLitro;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdVeiculo() {
        return idVeiculo;
    }

    public void setIdVeiculo(int idVeiculo) {
        this.idVeiculo = idVeiculo;
    }

    public int getIdPosto() {
        return idPosto;
    }

    public void setIdPosto(int idPosto) {
        this.idPosto = idPosto;
    }

    public int getIdCombustivel() {
        return idCombustivel;
    }

    public void setIdCombustivel(int idCombustivel) {
        this.idCombustivel = idCombustivel;
    }

    public Date getDataAbastecimento() {
        return dataAbastecimento;
    }

    public void setDataAbastecimento(Date dataAbastecimento) {
        this.dataAbastecimento = dataAbastecimento;
    }

    public double getLitrosAbastecidos() {
        return litrosAbastecidos;
    }

    public void setLitrosAbastecidos(double litrosAbastecidos) {
        this.litrosAbastecidos = litrosAbastecidos;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public double getDistanciaMediaPorLitro() {
        return distanciaMediaPorLitro;
    }

    public void setDistanciaMediaPorLitro(double distanciaMediaPorLitro) {
        this.distanciaMediaPorLitro = distanciaMediaPorLitro;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public Posto getPosto() {
        return posto;
    }

    public void setPosto(Posto posto) {
        this.posto = posto;
    }

    public TipoCombustivel getTipoCombustivel() {
        return tipoCombustivel;
    }

    public void setTipoCombustivel(TipoCombustivel tipoCombustivel) {
        this.tipoCombustivel = tipoCombustivel;
    }
}
