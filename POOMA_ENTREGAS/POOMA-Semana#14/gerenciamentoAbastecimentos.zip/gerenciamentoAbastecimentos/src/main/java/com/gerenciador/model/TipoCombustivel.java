package main.java.com.gerenciador.model;

import java.text.NumberFormat;
import java.util.Locale;

public class TipoCombustivel {
    private int id;
    private String nome;
    private String tipo; // Exemplo: gasolina, álcool, diesel
    private double precoPorLitro;

    // Construtores
    public TipoCombustivel() {
    }

    public TipoCombustivel(int id, String nome, String tipo, double precoPorLitro) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
        this.precoPorLitro = precoPorLitro;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecoPorLitro() {
        return precoPorLitro;
    }

    public void setPrecoPorLitro(double precoPorLitro) {
        this.precoPorLitro = precoPorLitro;
    }

    @Override
    public String toString() {
        // Formatar o valor como R$
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
        String valorFormatado = numberFormat.format(getPrecoPorLitro());

        return String.format("%s | %s | %s", getNome(), getTipo(), valorFormatado);
    }
}
