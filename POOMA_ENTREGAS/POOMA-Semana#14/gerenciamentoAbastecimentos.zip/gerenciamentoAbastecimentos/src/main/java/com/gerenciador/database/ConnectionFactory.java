package main.java.com.gerenciador.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionFactory {
    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String USER = "root";
    private static final String PASSWORD = "root";
    private static final String DATABASE_NAME = "app_postos";

    public static Connection createConnection() throws SQLException {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

            Statement statement = connection.createStatement();
            String createDatabase = "CREATE DATABASE IF NOT EXISTS " + DATABASE_NAME;
            statement.executeUpdate(createDatabase);

            // Seleciona o banco de dados recém-criado ou já existente
            String useDatabase = "USE " + DATABASE_NAME;
            statement.executeUpdate(useDatabase);

            return connection;
        } catch (Exception e) {
            throw new SQLException("Erro ao criar a conexão com o banco de dados", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);

            Statement statement = connection.createStatement();
            statement.execute("USE " + DATABASE_NAME);

            return connection;
        } catch (Exception e) {
            throw new SQLException("Erro ao criar a conexão com o banco de dados", e);
        }
    }
}
