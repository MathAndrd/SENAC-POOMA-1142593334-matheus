package main.java.com.gerenciador.view;

import main.java.com.gerenciador.controller.AbastecimentoController;
import main.java.com.gerenciador.controller.TipoCombustivelController;
import main.java.com.gerenciador.controller.VeiculoController;
import main.java.com.gerenciador.controller.PostoController;
import main.java.com.gerenciador.database.ConnectionFactory;
import main.java.com.gerenciador.model.Abastecimento;
import main.java.com.gerenciador.model.Posto;
import main.java.com.gerenciador.model.TipoCombustivel;
import main.java.com.gerenciador.model.Veiculo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

public class TelaPrincipal {
    private JFrame frame;
    private VeiculoController veiculoController;
    private PostoController postoController;
    private TipoCombustivelController tipoCombustivelController;
    private AbastecimentoController abastecimentoController;
    private JTable veiculoTable;
    private JTable postoTable;
    private JTable tipoCombustivelTable;

    public TelaPrincipal() throws SQLException {
        veiculoController = new VeiculoController(ConnectionFactory.getConnection());
        postoController = new PostoController(ConnectionFactory.getConnection());
        tipoCombustivelController = new TipoCombustivelController(ConnectionFactory.getConnection());
        abastecimentoController = new AbastecimentoController(ConnectionFactory.getConnection());
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Tela Principal");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);

        JMenuBar menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);

        JMenu cadastrosMenu = new JMenu("Cadastros");
        menuBar.add(cadastrosMenu);

        JMenuItem veiculoSubMenu = new JMenuItem("Veículo");
        cadastrosMenu.add(veiculoSubMenu);

        veiculoSubMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirMenuVeiculo();
            }
        });

        JMenuItem postoSubMenu = new JMenuItem("Posto");
        cadastrosMenu.add(postoSubMenu);

        postoSubMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirMenuPosto();
            }
        });

        JMenuItem tpCombSubMenu = new JMenuItem("Combustível");
        cadastrosMenu.add(tpCombSubMenu);

        tpCombSubMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirMenuTipoCombustivel();
            }
        });

        JMenu registroAbastecimentoMenu = new JMenu("Registro de Abastecimento");
        menuBar.add(registroAbastecimentoMenu);

        JMenuItem cadastrarAbastecimentoItem = new JMenuItem("Cadastrar Abastecimento");
        registroAbastecimentoMenu.add(cadastrarAbastecimentoItem);

        cadastrarAbastecimentoItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirRegistroAbastecimento();
            }
        });

        JMenuItem listarAbastecimentosItem = new JMenuItem("Listar Abastecimentos");
        registroAbastecimentoMenu.add(listarAbastecimentosItem);

        listarAbastecimentosItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarAbastecimentos();
            }
        });

        JMenuItem excluirAbastecimentosItem = new JMenuItem("Excluir Abastecimento");
        registroAbastecimentoMenu.add(excluirAbastecimentosItem);

        excluirAbastecimentosItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirAbastecimento();
            }
        });

        frame.setVisible(true);
    }

    public void exibirMenuVeiculo() {
        String[] options = {"Cadastrar", "Listar", "Atualizar", "Excluir"};
        int choice = JOptionPane.showOptionDialog(frame, "Escolha uma opção:", "Menu Veículo", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                cadastrarVeiculo();
                break;
            case 1:
                listarVeiculos();
                break;
            case 2:
                atualizarVeiculo();
                break;
            case 3:
                excluirVeiculo();
                break;
            default:
                break;
        }
    }

    private void cadastrarVeiculo() {
        VeiculoGUI veiculoGUI = new VeiculoGUI(veiculoController);
        veiculoGUI.exibir();
    }

    private void listarVeiculos() {
        List<Veiculo> veiculos = veiculoController.listaVeiculos();

        if (veiculos != null && !veiculos.isEmpty()) {
            String[] colunas = {"ID", "Marca", "Modelo", "Placa", "Renavam", "Km/litro"};
            Object[][] dados = new Object[veiculos.size()][colunas.length];

            for (int i = 0; i < veiculos.size(); i++) {
                Veiculo veiculo = veiculos.get(i);
                dados[i][0] = veiculo.getId();
                dados[i][1] = veiculo.getMarca();
                dados[i][2] = veiculo.getModelo();
                dados[i][3] = veiculo.getPlaca();
                dados[i][4] = veiculo.getRenavam();
                dados[i][5] = veiculo.getKmPorLitro();
            }

            veiculoTable = new JTable(dados, colunas);
            JScrollPane scrollPane = new JScrollPane(veiculoTable);

            JOptionPane.showMessageDialog(frame, scrollPane, "Lista de Veículos", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Nenhum veículo cadastrado.", "Lista de Veículos", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void atualizarVeiculo() {
        int veiculoId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Veículo a ser atualizado:"));

        Veiculo veiculo = veiculoController.buscarVeiculoPorId(veiculoId);
        if (veiculo != null) {
            VeiculoGUI veiculoGUI = new VeiculoGUI(veiculoController);
            veiculoGUI.exibir();

            veiculoGUI.preencherCampos(veiculo);
        } else {
            JOptionPane.showMessageDialog(frame, "Veículo não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirVeiculo() {
        int veiculoId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Veículo a ser excluído:"));

        veiculoController.excluirVeiculo(veiculoId);
        JOptionPane.showMessageDialog(frame, "Veículo excluído com sucesso.", "Exclusão", JOptionPane.INFORMATION_MESSAGE);
    }

    public void exibirMenuPosto() {
        String[] options = {"Cadastrar", "Listar", "Atualizar", "Excluir"};
        int choice = JOptionPane.showOptionDialog(frame, "Escolha uma opção:", "Menu Posto", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                cadastrarPosto();
                break;
            case 1:
                listarPostos();
                break;
            case 2:
                atualizarPosto();
                break;
            case 3:
                excluirPosto();
                break;
            default:
                break;
        }
    }

    private void cadastrarPosto() {
        PostoGUI postoGUI = new PostoGUI(postoController);
        postoGUI.exibir();
    }

    private void listarPostos() {
        List<Posto> postos = postoController.listaPostos();

        if (postos != null && !postos.isEmpty()) {
            String[] colunas = {"ID", "Nome", "Local"};
            Object[][] dados = new Object[postos.size()][colunas.length];

            for (int i = 0; i < postos.size(); i++) {
                Posto posto = postos.get(i);
                dados[i][0] = posto.getId();
                dados[i][1] = posto.getNome();
                dados[i][2] = posto.getLocal();
            }

            postoTable = new JTable(dados, colunas);
            JScrollPane scrollPane = new JScrollPane(postoTable);

            JOptionPane.showMessageDialog(frame, scrollPane, "Lista de Postos", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Nenhum posto cadastrado.", "Lista de Postos", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void atualizarPosto() {
        int postoId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Posto a ser atualizado:"));

        Posto posto = postoController.buscarPostoPorId(postoId);
        if (posto != null) {
            PostoGUI postoGUI = new PostoGUI(postoController);
            postoGUI.exibir();

            postoGUI.preencherCampos(posto);
        } else {
            JOptionPane.showMessageDialog(frame, "Posto não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirPosto() {
        int postoId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Posto a ser excluído:"));

        postoController.excluirPosto(postoId);
        JOptionPane.showMessageDialog(frame, "Posto excluído com sucesso.", "Exclusão", JOptionPane.INFORMATION_MESSAGE);
    }

    public void exibirMenuTipoCombustivel() {
        String[] options = {"Cadastrar", "Listar", "Atualizar", "Excluir"};
        int choice = JOptionPane.showOptionDialog(frame, "Escolha uma opção:", "Menu Tipo Combustível", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                cadastrarTipoCombustivel();
                break;
            case 1:
                listarTiposCombustivel();
                break;
            case 2:
                atualizarTipoCombustivel();
                break;
            case 3:
                excluirTipoCombustivel();
                break;
            default:
                break;
        }
    }

    private void cadastrarTipoCombustivel() {
        TipoCombustivelGUI tipoCombustivelGUI = new TipoCombustivelGUI(tipoCombustivelController);
        tipoCombustivelGUI.exibir();
    }

    private void listarTiposCombustivel() {
        List<TipoCombustivel> tiposCombustivel = tipoCombustivelController.listarTiposCombustivel();

        if (tiposCombustivel != null && !tiposCombustivel.isEmpty()) {
            String[] colunas = {"ID", "Nome", "Tipo", "Preço por Litro"};
            Object[][] dados = new Object[tiposCombustivel.size()][colunas.length];

            for (int i = 0; i < tiposCombustivel.size(); i++) {
                TipoCombustivel tipoCombustivel = tiposCombustivel.get(i);
                dados[i][0] = tipoCombustivel.getId();
                dados[i][1] = tipoCombustivel.getNome();
                dados[i][2] = tipoCombustivel.getTipo();
                dados[i][3] = tipoCombustivel.getPrecoPorLitro();
            }

            tipoCombustivelTable = new JTable(dados, colunas);
            JScrollPane scrollPane = new JScrollPane(tipoCombustivelTable);

            JOptionPane.showMessageDialog(frame, scrollPane, "Lista de Tipos de Combustível", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Nenhum tipo de combustível cadastrado.", "Lista de Tipos de Combustível", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void atualizarTipoCombustivel() {
        int tipoCombustivelId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Tipo de Combustível a ser atualizado:"));

        TipoCombustivel tipoCombustivel = tipoCombustivelController.buscarTipoCombustivelPorId(tipoCombustivelId);
        if (tipoCombustivel != null) {
            TipoCombustivelGUI tipoCombustivelGUI = new TipoCombustivelGUI(tipoCombustivelController);
            tipoCombustivelGUI.exibir();

            tipoCombustivelGUI.preencherCampos(tipoCombustivel);
        } else {
            JOptionPane.showMessageDialog(frame, "Tipo de Combustível não encontrado.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void excluirTipoCombustivel() {
        int tipoCombustivelId = Integer.parseInt(JOptionPane.showInputDialog(frame, "Digite o ID do Tipo de Combustível a ser excluído:"));

        tipoCombustivelController.excluirTipoCombustivel(tipoCombustivelId);
        JOptionPane.showMessageDialog(frame, "Tipo de Combustível excluído com sucesso.", "Exclusão", JOptionPane.INFORMATION_MESSAGE);
    }


    private void abrirRegistroAbastecimento() {
        // Chama a interface gráfica para o registro de abastecimento
        AbastecimentoGUI abastecimentoGUI = new AbastecimentoGUI(abastecimentoController);
        abastecimentoGUI.exibir();
    }

    private void listarAbastecimentos() {
        String[] opcoesOrdenacao = {"id", "data_abastecimento", "litros_abastecidos", "placa", "posto_nome"};
        String colunaSelecionada = (String) JOptionPane.showInputDialog(frame, "Selecione a coluna de ordenação:",
                "Ordenar por", JOptionPane.QUESTION_MESSAGE, null, opcoesOrdenacao, opcoesOrdenacao[0]);

        String[] opcoesTipoOrdem = {"ASC", "DESC"};
        String tipoOrdemSelecionada = (String) JOptionPane.showInputDialog(frame, "Selecione o tipo de ordenação:",
                "Tipo de ordem", JOptionPane.QUESTION_MESSAGE, null, opcoesTipoOrdem, opcoesTipoOrdem[0]);

        if (colunaSelecionada != null && tipoOrdemSelecionada != null) {
            AbastecimentoGUI abastecimentoGUI = new AbastecimentoGUI(abastecimentoController);
            abastecimentoGUI.exibirListaAbastecimentos(colunaSelecionada, tipoOrdemSelecionada);
        }
    }

    private void excluirAbastecimento() {
        String idAbastecimento = JOptionPane.showInputDialog(frame, "Informe o ID do Abastecimento a ser excluído:");

        try {
            if (idAbastecimento != null && !idAbastecimento.isEmpty()) {
                int abastecimentoId = Integer.parseInt(idAbastecimento);

                // Obtenha detalhes do abastecimento
                Abastecimento abastecimento = abastecimentoController.buscarAbastecimentoPorId(abastecimentoId);

                if (abastecimento != null) {
                    int confirmacao = JOptionPane.showConfirmDialog(frame,
                            "Você está prestes a excluir o seguinte abastecimento:\n\n" +
                                    "ID: " + abastecimento.getId() + "\n" +
                                    "Data: " + abastecimento.getDataAbastecimento() + "\n" +
                                    "Litros: " + abastecimento.getLitrosAbastecidos() + "\n" +
                                    "Valor: " + abastecimento.getValorTotal() + "\n" +
                                    "\nDeseja continuar?",
                            "Confirmação de Exclusão",
                            JOptionPane.YES_NO_OPTION);

                    if (confirmacao == JOptionPane.YES_OPTION) {
                        abastecimentoController.excluirAbastecimento(abastecimentoId);
                        JOptionPane.showMessageDialog(frame, "Abastecimento excluído com sucesso.");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Abastecimento não encontrado.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Informe um ID válido.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Erro ao processar a exclusão.");
        }
    }

}
