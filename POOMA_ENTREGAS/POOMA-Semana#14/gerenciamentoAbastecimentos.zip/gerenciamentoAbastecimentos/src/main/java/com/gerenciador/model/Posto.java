package main.java.com.gerenciador.model;

public class Posto {
    private int id;
    private String nome;
    private String local;

    // Construtores
    public Posto(){
    }
    public Posto(int id, String nome, String local) {
        this.id = id;
        this.nome = nome;
        this.local = local;
    }

    // Métodos getter e setter para os atributos

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    @Override
    public String toString() {
        return String.format("%s | %s", getNome(), getLocal());
    }
}
