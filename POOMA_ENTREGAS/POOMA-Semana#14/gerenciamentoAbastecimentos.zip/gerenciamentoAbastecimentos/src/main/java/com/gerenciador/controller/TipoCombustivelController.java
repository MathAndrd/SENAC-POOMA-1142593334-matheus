package main.java.com.gerenciador.controller;

import main.java.com.gerenciador.dao.TipoCombustivelDAO;
import main.java.com.gerenciador.model.TipoCombustivel;
import main.java.com.gerenciador.view.TipoCombustivelGUI;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class TipoCombustivelController {
    private TipoCombustivelDAO tipoCombustivelDAO;
    private TipoCombustivelGUI tipoCombustivelGUI;

    public TipoCombustivelController(Connection connection) {
        this.tipoCombustivelDAO = new TipoCombustivelDAO(connection);
        this.tipoCombustivelGUI = new TipoCombustivelGUI(this);
    }

    public void cadastrarTipoCombustivel(String nome, String tipo, double precoPorLitro) {
        try {
            TipoCombustivel tipoCombustivel = new TipoCombustivel(0, nome, tipo, precoPorLitro);
            tipoCombustivelDAO.inserirTipoCombustivel(tipoCombustivel);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<TipoCombustivel> listarTiposCombustivel() {
        try {
            return tipoCombustivelDAO.listarTiposCombustivel();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void atualizarTipoCombustivel(int tipoCombustivelId, String nome, String tipo, double precoPorLitro) {
        try {
            TipoCombustivel tipoCombustivel = new TipoCombustivel(tipoCombustivelId, nome, tipo, precoPorLitro);
            tipoCombustivelDAO.atualizarTipoCombustivel(tipoCombustivel);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirTipoCombustivel(int tipoCombustivelId) {
        try {
            tipoCombustivelDAO.excluirTipoCombustivel(tipoCombustivelId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public TipoCombustivel buscarTipoCombustivelPorId(int tipoCombustivelId) {
        try {
            return tipoCombustivelDAO.buscarTipoCombustivelPorId(tipoCombustivelId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<String> getNomesTiposCombustivel() throws SQLException {
        return tipoCombustivelDAO.listarNomesTiposCombustivel();
    }

}

