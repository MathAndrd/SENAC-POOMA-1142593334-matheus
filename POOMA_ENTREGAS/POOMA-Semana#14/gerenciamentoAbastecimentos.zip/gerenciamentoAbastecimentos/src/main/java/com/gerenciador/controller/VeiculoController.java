package main.java.com.gerenciador.controller;

import main.java.com.gerenciador.dao.VeiculoDAO;
import main.java.com.gerenciador.model.Veiculo;
import main.java.com.gerenciador.view.VeiculoGUI;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class VeiculoController {
    private VeiculoDAO veiculoDAO;
    private VeiculoGUI veiculoGUI;

    public VeiculoController(Connection connection) {
        this.veiculoDAO = new VeiculoDAO(connection);
        this.veiculoGUI = new VeiculoGUI(this);
    }

    public void cadastrarVeiculo(String marca, String modelo, String placa, String renavam, double kmPorLitro) {
        try {
            Veiculo veiculo = new Veiculo(0, marca, modelo, placa, renavam, kmPorLitro);
            veiculoDAO.inserirVeiculo(veiculo);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Veiculo> listaVeiculos() {
        try {
            return veiculoDAO.listarVeiculos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void atualizarVeiculo(int veiculoId, String marca, String modelo, String placa, String renavam, double kmPorLitro) {
        try {
            Veiculo veiculo = new Veiculo(veiculoId, marca, modelo, placa, renavam, kmPorLitro);
            veiculoDAO.atualizarVeiculo(veiculo);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirVeiculo(int veiculoId) {
        try {
            veiculoDAO.excluirVeiculo(veiculoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Veiculo buscarVeiculoPorId(int veiculoId) {
        try {
            return veiculoDAO.buscarVeiculoPorId(veiculoId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Adicione este método à classe VeiculoController
    public List<String> getNomesVeiculos() throws SQLException {
        return veiculoDAO.listarNomesVeiculos();
    }

}
