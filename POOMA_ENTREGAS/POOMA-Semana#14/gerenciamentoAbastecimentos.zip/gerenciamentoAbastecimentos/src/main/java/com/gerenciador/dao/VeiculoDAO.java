package main.java.com.gerenciador.dao;

import main.java.com.gerenciador.model.Veiculo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO {
    private Connection connection;

    // Construtor que recebe a conexão
    public VeiculoDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para inserir um veículo no banco de dados
    public void inserirVeiculo(Veiculo veiculo) throws SQLException {
        String sql = "INSERT INTO veiculo (marca, modelo, placa, renavam, kmPorLitro) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, veiculo.getMarca());
            statement.setString(2, veiculo.getModelo());
            statement.setString(3, veiculo.getPlaca());
            statement.setString(4, veiculo.getRenavam());
            statement.setDouble(5, veiculo.getKmPorLitro());
            statement.executeUpdate();
        }
    }

    // Método para buscar todos os veículos no banco de dados
    public List<Veiculo> listarVeiculos() throws SQLException {
        List<Veiculo> veiculos = new ArrayList<>();
        String sql = "SELECT * FROM veiculo";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Veiculo veiculo = new Veiculo();
                veiculo.setId(resultSet.getInt("id"));
                veiculo.setMarca(resultSet.getString("marca"));
                veiculo.setModelo(resultSet.getString("modelo"));
                veiculo.setPlaca(resultSet.getString("placa"));
                veiculo.setRenavam(resultSet.getString("renavam"));
                veiculo.setKmPorLitro(resultSet.getDouble("kmPorLitro"));
                veiculos.add(veiculo);
            }
        }
        return veiculos;
    }
    // Método para atualizar um veículo no banco de dados
    public void atualizarVeiculo(Veiculo veiculo) throws SQLException {
        String sql = "UPDATE veiculo SET marca=?, modelo=?, placa=?, renavam=?, kmPorLitro=? WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, veiculo.getMarca());
            statement.setString(2, veiculo.getModelo());
            statement.setString(3, veiculo.getPlaca());
            statement.setString(4, veiculo.getRenavam());
            statement.setDouble(5, veiculo.getKmPorLitro());
            statement.setInt(6, veiculo.getId());
            statement.executeUpdate();
        }
    }

    // Método para excluir um veículo do banco de dados
    public void excluirVeiculo(int veiculoId) throws SQLException {
        String sql = "DELETE FROM veiculo WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, veiculoId);
            statement.executeUpdate();
        }
    }

    // Método para buscar um veículo por ID
    public Veiculo buscarVeiculoPorId(int veiculoId) throws SQLException {
        String sql = "SELECT * FROM veiculo WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, veiculoId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Veiculo veiculo = new Veiculo();
                    veiculo.setId(resultSet.getInt("id"));
                    veiculo.setMarca(resultSet.getString("marca"));
                    veiculo.setModelo(resultSet.getString("modelo"));
                    veiculo.setPlaca(resultSet.getString("placa"));
                    veiculo.setRenavam(resultSet.getString("renavam"));
                    veiculo.setKmPorLitro(resultSet.getDouble("kmPorLitro"));
                    return veiculo;
                }
            }
        }
        return null;
    }

    // Adicione este método à classe VeiculoDAO
    public List<String> listarNomesVeiculos() throws SQLException {
        List<String> nomesVeiculos = new ArrayList<>();
        String sql = "SELECT nome FROM veiculo";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                nomesVeiculos.add(resultSet.getString("nome"));
            }
        }
        return nomesVeiculos;
    }

}